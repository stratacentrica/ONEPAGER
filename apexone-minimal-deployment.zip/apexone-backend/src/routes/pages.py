from flask import Blueprint, request, jsonify
import json
import os
from datetime import datetime, timedelta
import uuid

pages_bp = Blueprint('pages', __name__)

@pages_bp.route('/pages/save', methods=['POST'])
def save_page():
    """Save a page design"""
    try:
        data = request.get_json()
        
        page_data = {
            'id': data.get('id') or str(uuid.uuid4()),
            'title': data.get('title', 'Untitled Page'),
            'components': data.get('components', []),
            'page_settings': data.get('page_settings', {}),
            'background_effects': data.get('background_effects', {}),
            'created_at': data.get('created_at') or datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat(),
            'user_id': data.get('user_id', 'anonymous')
        }
        
        # Save to database/file
        pages_file = os.path.join(os.path.dirname(__file__), '..', 'database', 'saved_pages.json')
        
        pages = []
        if os.path.exists(pages_file):
            with open(pages_file, 'r') as f:
                pages = json.load(f)
        
        # Update existing page or add new one
        existing_index = next((i for i, p in enumerate(pages) if p['id'] == page_data['id']), None)
        if existing_index is not None:
            pages[existing_index] = page_data
        else:
            pages.append(page_data)
        
        with open(pages_file, 'w') as f:
            json.dump(pages, f, indent=2)
        
        return jsonify({
            'success': True,
            'page_id': page_data['id'],
            'message': 'Page saved successfully'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@pages_bp.route('/pages/load/<page_id>', methods=['GET'])
def load_page(page_id):
    """Load a saved page design"""
    try:
        pages_file = os.path.join(os.path.dirname(__file__), '..', 'database', 'saved_pages.json')
        
        if not os.path.exists(pages_file):
            return jsonify({'error': 'Page not found'}), 404
        
        with open(pages_file, 'r') as f:
            pages = json.load(f)
        
        page = next((p for p in pages if p['id'] == page_id), None)
        if not page:
            return jsonify({'error': 'Page not found'}), 404
        
        return jsonify({
            'success': True,
            'page': page
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@pages_bp.route('/pages/list', methods=['GET'])
def list_pages():
    """List all saved pages"""
    try:
        user_id = request.args.get('user_id', 'anonymous')
        
        pages_file = os.path.join(os.path.dirname(__file__), '..', 'database', 'saved_pages.json')
        
        if not os.path.exists(pages_file):
            return jsonify({'success': True, 'pages': []})
        
        with open(pages_file, 'r') as f:
            all_pages = json.load(f)
        
        # Filter by user_id if provided
        if user_id != 'all':
            pages = [p for p in all_pages if p.get('user_id') == user_id]
        else:
            pages = all_pages
        
        # Return summary info only
        page_summaries = []
        for page in pages:
            page_summaries.append({
                'id': page['id'],
                'title': page['title'],
                'created_at': page['created_at'],
                'updated_at': page['updated_at'],
                'component_count': len(page.get('components', []))
            })
        
        return jsonify({
            'success': True,
            'pages': page_summaries
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@pages_bp.route('/pages/delete/<page_id>', methods=['DELETE'])
def delete_page(page_id):
    """Delete a saved page"""
    try:
        pages_file = os.path.join(os.path.dirname(__file__), '..', 'database', 'saved_pages.json')
        
        if not os.path.exists(pages_file):
            return jsonify({'error': 'Page not found'}), 404
        
        with open(pages_file, 'r') as f:
            pages = json.load(f)
        
        # Remove the page
        pages = [p for p in pages if p['id'] != page_id]
        
        with open(pages_file, 'w') as f:
            json.dump(pages, f, indent=2)
        
        return jsonify({
            'success': True,
            'message': 'Page deleted successfully'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@pages_bp.route('/pages/duplicate/<page_id>', methods=['POST'])
def duplicate_page(page_id):
    """Duplicate an existing page"""
    try:
        pages_file = os.path.join(os.path.dirname(__file__), '..', 'database', 'saved_pages.json')
        
        if not os.path.exists(pages_file):
            return jsonify({'error': 'Page not found'}), 404
        
        with open(pages_file, 'r') as f:
            pages = json.load(f)
        
        original_page = next((p for p in pages if p['id'] == page_id), None)
        if not original_page:
            return jsonify({'error': 'Page not found'}), 404
        
        # Create duplicate
        duplicate_page = original_page.copy()
        duplicate_page['id'] = str(uuid.uuid4())
        duplicate_page['title'] = f"{original_page['title']} (Copy)"
        duplicate_page['created_at'] = datetime.now().isoformat()
        duplicate_page['updated_at'] = datetime.now().isoformat()
        
        # Update component IDs to avoid conflicts
        new_components = []
        for component in duplicate_page.get('components', []):
            new_component = component.copy()
            new_component['id'] = str(uuid.uuid4())
            new_components.append(new_component)
        duplicate_page['components'] = new_components
        
        pages.append(duplicate_page)
        
        with open(pages_file, 'w') as f:
            json.dump(pages, f, indent=2)
        
        return jsonify({
            'success': True,
            'page_id': duplicate_page['id'],
            'message': 'Page duplicated successfully'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@pages_bp.route('/pages/templates', methods=['GET'])
def get_templates():
    """Get predefined page templates"""
    templates = [
        {
            'id': 'template_hero_cta',
            'name': 'Hero + CTA',
            'description': 'Hero banner with call-to-action button',
            'preview_image': '/static/templates/hero-cta.png',
            'components': [
                {
                    'id': 'hero_1',
                    'type': 'hero-banner',
                    'position': {'x': 100, 'y': 100},
                    'content': {
                        'title': 'Welcome to APEXONE',
                        'subtitle': 'Build Amazing Landing Pages',
                        'description': 'Create stunning, professional landing pages in minutes',
                        'ctaText': 'Get Started Now'
                    }
                },
                {
                    'id': 'cta_1',
                    'type': 'cta-button',
                    'position': {'x': 300, 'y': 550},
                    'content': {
                        'text': 'Start Building',
                        'type': 'signup'
                    }
                }
            ]
        },
        {
            'id': 'template_audio_showcase',
            'name': 'Audio Showcase',
            'description': 'Perfect for music and podcast promotion',
            'preview_image': '/static/templates/audio-showcase.png',
            'components': [
                {
                    'id': 'audio_1',
                    'type': 'audio',
                    'position': {'x': 150, 'y': 200},
                    'content': {
                        'name': 'APEXONE Radio',
                        'url': 'https://s135.radiolize.com/radio/8110/radio.mp3',
                        'autoplay': False,
                        'loop': True
                    }
                },
                {
                    'id': 'atmosphere_1',
                    'type': 'atmospheric-audio',
                    'position': {'x': 500, 'y': 200},
                    'content': {
                        'atmosphere': 'space',
                        'volume': 30,
                        'loop': True
                    }
                }
            ]
        },
        {
            'id': 'template_business_form',
            'name': 'Business Contact',
            'description': 'Professional contact form with timer',
            'preview_image': '/static/templates/business-form.png',
            'components': [
                {
                    'id': 'form_1',
                    'type': 'form',
                    'position': {'x': 200, 'y': 150},
                    'content': {
                        'title': 'Contact Us',
                        'fields': [
                            {'name': 'email', 'type': 'email', 'placeholder': 'Your email', 'required': True},
                            {'name': 'message', 'type': 'textarea', 'placeholder': 'Your message', 'required': True}
                        ]
                    }
                },
                {
                    'id': 'timer_1',
                    'type': 'timer',
                    'position': {'x': 550, 'y': 150},
                    'content': {
                        'title': 'Limited Time Offer',
                        'endDate': (datetime.now() + timedelta(days=7)).isoformat()
                    }
                }
            ]
        }
    ]
    
    return jsonify({
        'success': True,
        'templates': templates
    })

