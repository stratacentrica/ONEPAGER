from flask import Blueprint, request, jsonify, send_file
import os
import zipfile
import tempfile
import json
from datetime import datetime

export_bp = Blueprint('export', __name__)

@export_bp.route('/export/html', methods=['POST'])
def export_html():
    """Export the current page design as clean HTML/CSS files"""
    try:
        data = request.get_json()
        page_data = data.get('pageData', {})
        components = data.get('components', [])
        
        # Generate clean HTML
        html_content = generate_clean_html(page_data, components)
        css_content = generate_clean_css(page_data, components)
        
        # Create temporary directory for files
        temp_dir = tempfile.mkdtemp()
        
        # Write HTML file
        html_path = os.path.join(temp_dir, 'index.html')
        with open(html_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        # Write CSS file
        css_path = os.path.join(temp_dir, 'styles.css')
        with open(css_path, 'w', encoding='utf-8') as f:
            f.write(css_content)
        
        # Create ZIP file
        zip_path = os.path.join(temp_dir, 'landing-page.zip')
        with zipfile.ZipFile(zip_path, 'w') as zipf:
            zipf.write(html_path, 'index.html')
            zipf.write(css_path, 'styles.css')
        
        return send_file(zip_path, as_attachment=True, download_name='landing-page.zip')
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@export_bp.route('/export/ftp-config', methods=['POST'])
def save_ftp_config():
    """Save FTP configuration for quick deployment"""
    try:
        data = request.get_json()
        ftp_config = {
            'host': data.get('host'),
            'username': data.get('username'),
            'port': data.get('port', 21),
            'directory': data.get('directory', '/public_html'),
            'saved_at': datetime.now().isoformat()
        }
        
        # Save to user's config (in production, this would be user-specific)
        config_path = os.path.join(os.path.dirname(__file__), '..', 'database', 'ftp_configs.json')
        
        configs = []
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                configs = json.load(f)
        
        configs.append(ftp_config)
        
        with open(config_path, 'w') as f:
            json.dump(configs, f, indent=2)
        
        return jsonify({'success': True, 'message': 'FTP configuration saved'})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@export_bp.route('/export/ftp-configs', methods=['GET'])
def get_ftp_configs():
    """Get saved FTP configurations"""
    try:
        config_path = os.path.join(os.path.dirname(__file__), '..', 'database', 'ftp_configs.json')
        
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                configs = json.load(f)
            return jsonify({'configs': configs})
        else:
            return jsonify({'configs': []})
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def generate_clean_html(page_data, components):
    """Generate clean, production-ready HTML"""
    background_style = ""
    if page_data.get('background_image'):
        background_style = f"background-image: url('{page_data['background_image']}'); background-size: cover; background-position: center;"
    if page_data.get('background_color'):
        background_style += f" background-color: {page_data['background_color']};"
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{page_data.get('title', 'Landing Page')}</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body style="{background_style}">
    <div class="page-container">
"""
    
    # Add components
    for component in components:
        html += generate_component_html(component)
    
    html += """
    </div>
</body>
</html>"""
    
    return html

def generate_component_html(component):
    """Generate HTML for individual components"""
    comp_type = component.get('type')
    content = component.get('content', {})
    style = component.get('style', {})
    position = component.get('position', {})
    
    # Generate inline styles
    inline_style = f"position: absolute; left: {position.get('x', 0)}px; top: {position.get('y', 0)}px;"
    for key, value in style.items():
        if key in ['fontSize', 'fontWeight', 'fontFamily', 'color', 'backgroundColor', 'borderRadius', 'padding']:
            css_key = key.replace('fontSize', 'font-size').replace('fontWeight', 'font-weight').replace('fontFamily', 'font-family').replace('backgroundColor', 'background-color').replace('borderRadius', 'border-radius')
            inline_style += f" {css_key}: {value};"
    
    if comp_type == 'text':
        return f'<div style="{inline_style}" class="component text-component">{content.get("text", "")}</div>\n'
    
    elif comp_type == 'button':
        return f'<button style="{inline_style}" class="component button-component">{content.get("text", "Click Me")}</button>\n'
    
    elif comp_type == 'hero-banner':
        return f'''<div style="{inline_style}" class="component hero-banner">
            <h1>{content.get("title", "Welcome")}</h1>
            <p>{content.get("subtitle", "Subtitle")}</p>
            <p>{content.get("description", "Description")}</p>
            <button class="cta-button">{content.get("ctaText", "Get Started")}</button>
        </div>\n'''
    
    elif comp_type == 'audio':
        return f'''<div style="{inline_style}" class="component audio-component">
            <audio controls autoplay="{content.get('autoplay', False)}" loop="{content.get('loop', False)}">
                <source src="{content.get('url', '')}" type="audio/mpeg">
            </audio>
        </div>\n'''
    
    else:
        return f'<div style="{inline_style}" class="component">{comp_type}</div>\n'

def generate_clean_css(page_data, components):
    """Generate clean, production-ready CSS"""
    css = """
/* APEXONE Landing Page Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    min-height: 100vh;
    position: relative;
}

.page-container {
    position: relative;
    width: 100%;
    min-height: 100vh;
}

.component {
    backdrop-filter: blur(12px);
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 12px;
    padding: 16px;
}

.text-component {
    color: white;
}

.button-component {
    background: rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.3);
    color: white;
    cursor: pointer;
    transition: all 0.3s ease;
}

.button-component:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: translateY(-2px);
}

.hero-banner {
    text-align: center;
    color: white;
}

.hero-banner h1 {
    font-size: 3rem;
    font-weight: 700;
    margin-bottom: 1rem;
}

.hero-banner p {
    font-size: 1.2rem;
    margin-bottom: 1rem;
    opacity: 0.9;
}

.cta-button {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
    color: white;
    padding: 12px 24px;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}

.cta-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
}

.audio-component audio {
    width: 100%;
    filter: invert(1) hue-rotate(180deg);
}

/* Responsive Design */
@media (max-width: 768px) {
    .hero-banner h1 {
        font-size: 2rem;
    }
    
    .hero-banner p {
        font-size: 1rem;
    }
}
"""
    
    return css

