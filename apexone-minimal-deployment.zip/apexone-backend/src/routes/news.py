from flask import Blueprint, request, jsonify
import requests
import json
import os
from datetime import datetime, timedelta

news_bp = Blueprint('news', __name__)

@news_bp.route('/news/search', methods=['POST'])
def search_news():
    """Search for news articles based on keywords"""
    try:
        data = request.get_json()
        keywords = data.get('keywords', [])
        max_articles = data.get('max_articles', 5)
        
        if not keywords:
            return jsonify({'error': 'Keywords are required'}), 400
        
        # Use a free news API (NewsAPI.org alternative or RSS feeds)
        articles = fetch_news_articles(keywords, max_articles)
        
        # Cache the results
        cache_news_results(keywords, articles)
        
        return jsonify({
            'success': True,
            'articles': articles,
            'keywords': keywords,
            'fetched_at': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@news_bp.route('/news/cached', methods=['GET'])
def get_cached_news():
    """Get cached news articles"""
    try:
        cache_path = os.path.join(os.path.dirname(__file__), '..', 'database', 'news_cache.json')
        
        if os.path.exists(cache_path):
            with open(cache_path, 'r') as f:
                cached_data = json.load(f)
            
            # Check if cache is still valid (24 hours)
            cached_time = datetime.fromisoformat(cached_data.get('cached_at', ''))
            if datetime.now() - cached_time < timedelta(hours=24):
                return jsonify({
                    'success': True,
                    'articles': cached_data.get('articles', []),
                    'cached_at': cached_data.get('cached_at'),
                    'from_cache': True
                })
        
        return jsonify({'success': True, 'articles': [], 'from_cache': False})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@news_bp.route('/news/component', methods=['POST'])
def create_news_component():
    """Create a dynamic news component with parsed articles"""
    try:
        data = request.get_json()
        keywords = data.get('keywords', [])
        style = data.get('style', 'card')  # card, list, ticker
        max_articles = data.get('max_articles', 3)
        
        # Fetch fresh articles
        articles = fetch_news_articles(keywords, max_articles)
        
        # Generate component HTML
        component_html = generate_news_component_html(articles, style)
        
        return jsonify({
            'success': True,
            'component_html': component_html,
            'articles': articles,
            'style': style
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def fetch_news_articles(keywords, max_articles=5):
    """Fetch news articles from various sources"""
    articles = []
    
    try:
        # Use RSS feeds as a free alternative to paid news APIs
        rss_sources = [
            'https://rss.cnn.com/rss/edition.rss',
            'https://feeds.bbci.co.uk/news/rss.xml',
            'https://rss.reuters.com/reuters/topNews',
            'https://feeds.npr.org/1001/rss.xml'
        ]
        
        for source in rss_sources[:2]:  # Limit to 2 sources for performance
            try:
                articles.extend(parse_rss_feed(source, keywords, max_articles // 2))
            except:
                continue
        
        # If no articles found, return sample articles
        if not articles:
            articles = get_sample_news_articles(keywords)
        
        return articles[:max_articles]
        
    except Exception as e:
        # Return sample articles if fetching fails
        return get_sample_news_articles(keywords)

def parse_rss_feed(rss_url, keywords, max_items):
    """Parse RSS feed and filter by keywords"""
    import xml.etree.ElementTree as ET
    
    try:
        response = requests.get(rss_url, timeout=10)
        root = ET.fromstring(response.content)
        
        articles = []
        keyword_lower = [k.lower() for k in keywords]
        
        for item in root.findall('.//item')[:max_items * 2]:  # Get more to filter
            title = item.find('title')
            description = item.find('description')
            link = item.find('link')
            pub_date = item.find('pubDate')
            
            if title is not None and description is not None:
                title_text = title.text or ''
                desc_text = description.text or ''
                
                # Check if any keyword matches
                if any(keyword in title_text.lower() or keyword in desc_text.lower() for keyword in keyword_lower):
                    articles.append({
                        'title': title_text,
                        'description': desc_text[:200] + '...' if len(desc_text) > 200 else desc_text,
                        'url': link.text if link is not None else '',
                        'published_at': pub_date.text if pub_date is not None else '',
                        'source': rss_url
                    })
                    
                    if len(articles) >= max_items:
                        break
        
        return articles
        
    except Exception as e:
        return []

def get_sample_news_articles(keywords):
    """Return sample news articles when real fetching fails"""
    keyword_str = ', '.join(keywords) if keywords else 'technology'
    
    return [
        {
            'title': f'Breaking: Latest developments in {keyword_str}',
            'description': f'Recent updates and trends in {keyword_str} are shaping the industry landscape with innovative solutions and breakthrough technologies.',
            'url': '#',
            'published_at': datetime.now().strftime('%a, %d %b %Y %H:%M:%S GMT'),
            'source': 'Sample News'
        },
        {
            'title': f'Industry Analysis: {keyword_str} Market Trends',
            'description': f'Comprehensive analysis of current market trends and future predictions in the {keyword_str} sector.',
            'url': '#',
            'published_at': (datetime.now() - timedelta(hours=2)).strftime('%a, %d %b %Y %H:%M:%S GMT'),
            'source': 'Sample News'
        },
        {
            'title': f'Expert Opinion: The Future of {keyword_str}',
            'description': f'Leading experts share their insights on the future direction and potential impact of {keyword_str} technologies.',
            'url': '#',
            'published_at': (datetime.now() - timedelta(hours=4)).strftime('%a, %d %b %Y %H:%M:%S GMT'),
            'source': 'Sample News'
        }
    ]

def generate_news_component_html(articles, style='card'):
    """Generate HTML for news component"""
    if style == 'card':
        html = '<div class="news-component news-cards">'
        for article in articles:
            html += f'''
            <div class="news-card">
                <h3 class="news-title">{article['title']}</h3>
                <p class="news-description">{article['description']}</p>
                <div class="news-meta">
                    <span class="news-source">{article.get('source', 'News')}</span>
                    <span class="news-date">{format_date(article.get('published_at', ''))}</span>
                </div>
            </div>
            '''
        html += '</div>'
        
    elif style == 'list':
        html = '<div class="news-component news-list">'
        for article in articles:
            html += f'''
            <div class="news-item">
                <h4 class="news-title">{article['title']}</h4>
                <p class="news-description">{article['description']}</p>
            </div>
            '''
        html += '</div>'
        
    elif style == 'ticker':
        html = '<div class="news-component news-ticker">'
        html += '<div class="ticker-content">'
        for article in articles:
            html += f'<span class="ticker-item">{article["title"]}</span>'
        html += '</div></div>'
    
    return html

def format_date(date_str):
    """Format date string for display"""
    try:
        if date_str:
            # Parse common RSS date format
            dt = datetime.strptime(date_str, '%a, %d %b %Y %H:%M:%S %Z')
            return dt.strftime('%b %d, %Y')
    except:
        pass
    return 'Recent'

def cache_news_results(keywords, articles):
    """Cache news results to avoid repeated API calls"""
    try:
        cache_data = {
            'keywords': keywords,
            'articles': articles,
            'cached_at': datetime.now().isoformat()
        }
        
        cache_path = os.path.join(os.path.dirname(__file__), '..', 'database', 'news_cache.json')
        
        with open(cache_path, 'w') as f:
            json.dump(cache_data, f, indent=2)
            
    except Exception as e:
        pass  # Fail silently for caching errors

