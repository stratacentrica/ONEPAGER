from flask import Blueprint, request, jsonify
import json
import os
from datetime import datetime

# ElevenLabs API configuration
ELEVENLABS_API_KEY = os.getenv('ELEVENLABS_API_KEY', '35c7db473b0ed744:6ba7a82e03c5d54099cacbce7b9f1112')
ELEVENLABS_API_KEY_SECONDARY = os.getenv('ELEVENLABS_API_KEY_SECONDARY', 'sk-proj-owCYlbPXi5R5fTrxLeM9_59ljwja9y5QT7t5271UlxsvjZatKW')

elevenlabs_bp = Blueprint('elevenlabs', __name__)

@elevenlabs_bp.route('/elevenlabs/widget-config', methods=['POST'])
def save_widget_config():
    """Save ElevenLabs widget configuration"""
    try:
        data = request.get_json()
        
        widget_config = {
            'agent_id': data.get('agent_id'),
            'variant': data.get('variant', 'expanded'),
            'avatar_image_url': data.get('avatar_image_url'),
            'avatar_orb_color_1': data.get('avatar_orb_color_1', '#6DB035'),
            'avatar_orb_color_2': data.get('avatar_orb_color_2', '#F5CABB'),
            'action_text': data.get('action_text', 'Need assistance?'),
            'start_call_text': data.get('start_call_text', 'Begin conversation'),
            'end_call_text': data.get('end_call_text', 'End call'),
            'expand_text': data.get('expand_text', 'Open chat'),
            'listening_text': data.get('listening_text', 'Listening...'),
            'speaking_text': data.get('speaking_text', 'Assistant speaking'),
            'dynamic_variables': data.get('dynamic_variables', {}),
            'override_language': data.get('override_language'),
            'override_prompt': data.get('override_prompt'),
            'override_first_message': data.get('override_first_message'),
            'override_voice_id': data.get('override_voice_id'),
            'saved_at': datetime.now().isoformat()
        }
        
        # Save configuration
        config_path = os.path.join(os.path.dirname(__file__), '..', 'database', 'elevenlabs_configs.json')
        
        configs = []
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                configs = json.load(f)
        
        configs.append(widget_config)
        
        with open(config_path, 'w') as f:
            json.dump(configs, f, indent=2)
        
        return jsonify({
            'success': True,
            'message': 'ElevenLabs widget configuration saved',
            'config': widget_config
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@elevenlabs_bp.route('/elevenlabs/widget-configs', methods=['GET'])
def get_widget_configs():
    """Get saved ElevenLabs widget configurations"""
    try:
        config_path = os.path.join(os.path.dirname(__file__), '..', 'database', 'elevenlabs_configs.json')
        
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                configs = json.load(f)
            return jsonify({'success': True, 'configs': configs})
        else:
            return jsonify({'success': True, 'configs': []})
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@elevenlabs_bp.route('/elevenlabs/generate-widget', methods=['POST'])
def generate_widget():
    """Generate ElevenLabs widget HTML code"""
    try:
        data = request.get_json()
        
        agent_id = data.get('agent_id')
        if not agent_id:
            return jsonify({'error': 'Agent ID is required'}), 400
        
        # Build widget attributes
        attributes = [f'agent-id="{agent_id}"']
        
        if data.get('variant'):
            attributes.append(f'variant="{data["variant"]}"')
        
        if data.get('avatar_image_url'):
            attributes.append(f'avatar-image-url="{data["avatar_image_url"]}"')
        
        if data.get('avatar_orb_color_1'):
            attributes.append(f'avatar-orb-color-1="{data["avatar_orb_color_1"]}"')
        
        if data.get('avatar_orb_color_2'):
            attributes.append(f'avatar-orb-color-2="{data["avatar_orb_color_2"]}"')
        
        if data.get('action_text'):
            attributes.append(f'action-text="{data["action_text"]}"')
        
        if data.get('start_call_text'):
            attributes.append(f'start-call-text="{data["start_call_text"]}"')
        
        if data.get('end_call_text'):
            attributes.append(f'end-call-text="{data["end_call_text"]}"')
        
        if data.get('expand_text'):
            attributes.append(f'expand-text="{data["expand_text"]}"')
        
        if data.get('listening_text'):
            attributes.append(f'listening-text="{data["listening_text"]}"')
        
        if data.get('speaking_text'):
            attributes.append(f'speaking-text="{data["speaking_text"]}"')
        
        if data.get('dynamic_variables'):
            variables_json = json.dumps(data['dynamic_variables']).replace('"', '&quot;')
            attributes.append(f'dynamic-variables="{variables_json}"')
        
        if data.get('override_language'):
            attributes.append(f'override-language="{data["override_language"]}"')
        
        if data.get('override_prompt'):
            attributes.append(f'override-prompt="{data["override_prompt"]}"')
        
        if data.get('override_first_message'):
            attributes.append(f'override-first-message="{data["override_first_message"]}"')
        
        if data.get('override_voice_id'):
            attributes.append(f'override-voice-id="{data["override_voice_id"]}"')
        
        # Generate widget HTML
        widget_html = f'''<!-- ElevenLabs Conversational AI Widget -->
<elevenlabs-convai
  {chr(10).join(f"  {attr}" for attr in attributes)}
></elevenlabs-convai>

<script
  src="https://unpkg.com/@elevenlabs/convai-widget-embed"
  async
  type="text/javascript"
></script>'''
        
        return jsonify({
            'success': True,
            'widget_html': widget_html,
            'attributes': attributes
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@elevenlabs_bp.route('/elevenlabs/component', methods=['POST'])
def create_elevenlabs_component():
    """Create an ElevenLabs widget component for the page builder"""
    try:
        data = request.get_json()
        
        agent_id = data.get('agent_id')
        if not agent_id:
            return jsonify({'error': 'Agent ID is required'}), 400
        
        # Create component data structure
        component = {
            'id': f'elevenlabs_{agent_id}',
            'type': 'elevenlabs-widget',
            'content': {
                'agent_id': agent_id,
                'variant': data.get('variant', 'expanded'),
                'action_text': data.get('action_text', 'Need assistance?'),
                'start_call_text': data.get('start_call_text', 'Begin conversation'),
                'end_call_text': data.get('end_call_text', 'End call'),
                'avatar_orb_color_1': data.get('avatar_orb_color_1', '#6DB035'),
                'avatar_orb_color_2': data.get('avatar_orb_color_2', '#F5CABB'),
                'dynamic_variables': data.get('dynamic_variables', {}),
                'override_language': data.get('override_language'),
                'override_prompt': data.get('override_prompt'),
                'override_first_message': data.get('override_first_message')
            },
            'style': {
                'position': 'fixed',
                'bottom': '20px',
                'right': '20px',
                'zIndex': 1000
            },
            'position': {
                'x': data.get('x', 800),
                'y': data.get('y', 500)
            }
        }
        
        return jsonify({
            'success': True,
            'component': component,
            'message': 'ElevenLabs widget component created'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@elevenlabs_bp.route('/elevenlabs/demo-agents', methods=['GET'])
def get_demo_agents():
    """Get demo agent configurations for testing"""
    demo_agents = [
        {
            'id': 'demo_customer_support',
            'name': 'Customer Support Agent',
            'description': 'Helpful customer service representative',
            'agent_id': 'demo-agent-customer-support',
            'suggested_prompt': 'You are a helpful customer support agent for APEXONE. Assist users with questions about our landing page builder.',
            'suggested_first_message': 'Hi! I\'m here to help you with APEXONE. What can I assist you with today?',
            'avatar_orb_color_1': '#667eea',
            'avatar_orb_color_2': '#764ba2'
        },
        {
            'id': 'demo_sales_assistant',
            'name': 'Sales Assistant',
            'description': 'Friendly sales and product information assistant',
            'agent_id': 'demo-agent-sales',
            'suggested_prompt': 'You are a knowledgeable sales assistant for APEXONE landing page builder. Help users understand our features and pricing.',
            'suggested_first_message': 'Welcome to APEXONE! I\'d love to help you learn about our powerful landing page builder. What would you like to know?',
            'avatar_orb_color_1': '#f093fb',
            'avatar_orb_color_2': '#f5576c'
        },
        {
            'id': 'demo_technical_support',
            'name': 'Technical Support',
            'description': 'Technical expert for troubleshooting and guidance',
            'agent_id': 'demo-agent-tech',
            'suggested_prompt': 'You are a technical support specialist for APEXONE. Help users with technical questions, troubleshooting, and implementation guidance.',
            'suggested_first_message': 'Hi there! I\'m your technical support specialist. How can I help you with APEXONE today?',
            'avatar_orb_color_1': '#4facfe',
            'avatar_orb_color_2': '#00f2fe'
        }
    ]
    
    return jsonify({
        'success': True,
        'demo_agents': demo_agents
    })

