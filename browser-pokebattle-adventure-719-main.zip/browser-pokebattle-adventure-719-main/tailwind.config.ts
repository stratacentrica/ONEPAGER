
import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        // Divine Rock Church Colors
        divine: {
          gold: "hsl(45 100% 50%)",
          "gold-light": "hsl(50 100% 60%)",
          "gold-dark": "hsl(40 100% 40%)",
        },
        rock: {
          black: "hsl(0 0% 10%)",
          "black-light": "hsl(0 0% 20%)",
          "black-dark": "hsl(0 0% 5%)",
        },
        cathedral: {
          stone: "hsl(0 0% 95%)",
          "stone-dark": "hsl(0 0% 90%)",
          white: "hsl(0 0% 100%)",
        },
        phone: {
          cream: "hsl(var(--phone-cream))",
          orange: "hsl(var(--phone-orange))",
          brown: "hsl(var(--phone-brown))",
          chrome: "hsl(var(--phone-chrome))",
        },
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      backgroundImage: {
        "gradient-divine": "var(--gradient-divine)",
        "gradient-cathedral": "var(--gradient-cathedral)",
        "gradient-rock": "var(--gradient-rock)",
      },
      boxShadow: {
        "divine": "var(--shadow-divine)",
        "cathedral": "var(--shadow-cathedral)",
        "glow": "var(--shadow-glow)",
      },
      keyframes: {
        "divine-glow": {
          "0%, 100%": { filter: "drop-shadow(0 0 20px hsl(45 100% 50% / 0.6))" },
          "50%": { filter: "drop-shadow(0 0 40px hsl(45 100% 50% / 0.8))" },
        },
        "cathedral-rise": {
          "0%": { transform: "translateY(20px) scale(0.95)", opacity: "0" },
          "100%": { transform: "translateY(0) scale(1)", opacity: "1" },
        },
        "rock-pulse": {
          "0%, 100%": { transform: "scale(1)" },
          "50%": { transform: "scale(1.05)" },
        },
        "telethon-flash": {
          "0%, 100%": { backgroundColor: "hsl(0 100% 50%)" },
          "50%": { backgroundColor: "hsl(45 100% 50%)" },
        },
        "handprint-activate": {
          "0%": { transform: "scale(1)", filter: "brightness(1)" },
          "50%": { transform: "scale(1.1)", filter: "brightness(1.5)" },
          "100%": { transform: "scale(1)", filter: "brightness(1)" },
        },
      },
      animation: {
        "divine-glow": "divine-glow 3s ease-in-out infinite",
        "cathedral-rise": "cathedral-rise 0.8s ease-out forwards",
        "rock-pulse": "rock-pulse 2s ease-in-out infinite",
        "telethon-flash": "telethon-flash 0.5s ease-in-out infinite",
        "handprint-activate": "handprint-activate 0.3s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config;
