
import React, { useState } from 'react';
import DivineUnit from '@/components/DivineUnit';
import ChurchHomepage from '@/components/ChurchHomepage';

const Index = () => {
  const [hasActivated, setHasActivated] = useState(false);

  if (!hasActivated) {
    return <DivineUnit onActivation={() => setHasActivated(true)} />;
  }

  return <ChurchHomepage />;
};

export default Index;
