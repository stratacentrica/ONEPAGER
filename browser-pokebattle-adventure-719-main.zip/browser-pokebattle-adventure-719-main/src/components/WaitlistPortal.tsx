import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';

interface Product {
  id: string;
  name: string;
  price: string;
  description: string;
  category: string;
  image: string;
}

interface WaitlistPortalProps {
  cart?: Product[];
  onBack: () => void;
}

const WaitlistPortal = ({ cart = [], onBack }: WaitlistPortalProps) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    lifeGoal: '',
    biggestFear: ''
  });
  const [orderNumber, setOrderNumber] = useState(111);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    // Load order number from cache or initialize
    const savedOrder = localStorage.getItem('divine-order-number');
    if (savedOrder) {
      setOrderNumber(parseInt(savedOrder) + 344); // Increment for return visit
    }
    localStorage.setItem('divine-order-number', orderNumber.toString());
  }, []);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    if (!formData.name || !formData.email || !formData.lifeGoal || !formData.biggestFear) {
      toast.error('Please fill in all divine fields to complete your spiritual profile!');
      return;
    }

    setIsSubmitting(true);

    // Simulate processing
    setTimeout(() => {
      const newOrderNumber = orderNumber + 1;
      setOrderNumber(newOrderNumber);
      localStorage.setItem('divine-order-number', newOrderNumber.toString());
      
      setIsSubmitting(false);
      setIsSubmitted(true);
      
      toast.success('Divine order received! You are blessed and chosen!');
    }, 3000);
  };

  const getTotalPrice = () => {
    return cart.reduce((sum, item) => sum + parseFloat(item.price.replace('$', '')), 0).toFixed(2);
  };

  return (
    <div className="min-h-screen bg-gradient-cathedral py-8">
      <div className="container mx-auto px-6 max-w-4xl">
        {/* Header */}
        <div className="flex items-center mb-8">
          <Button
            onClick={onBack}
            variant="outline"
            className="flex items-center space-x-2"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Sacred Shop</span>
          </Button>
          <h1 className="text-3xl md:text-4xl font-bold text-rock-black text-center flex-1">
            Divine Waitlist Portal
          </h1>
        </div>

        {!isSubmitted ? (
          <div className="cathedral-rise space-y-8">
            {/* Welcome Message */}
            <Card className="p-8 text-center shadow-divine bg-gradient-divine">
              <h2 className="text-4xl font-bold text-rock-black mb-4">
                CHURCH OF ROCK AND ROLL AND FREEDOM
              </h2>
              <h3 className="text-2xl font-bold text-divine-gold mb-4">
                Official 2025 Signature Roll Premier Roll Out
              </h3>
              <p className="text-xl text-rock-black mb-6">
                Don't worry, you don't need your card - we trust you like we trust ourselves.
              </p>
              <p className="text-2xl font-bold text-divine-gold">
                All gods are good gods! 🙏
              </p>
            </Card>

            {/* Order Summary */}
            {cart.length > 0 && (
              <Card className="p-6 shadow-cathedral">
                <h3 className="text-2xl font-bold text-rock-black mb-4">Your Sacred Order</h3>
                <div className="space-y-3 mb-4">
                  {cart.map((item, index) => (
                    <div key={index} className="flex justify-between items-center py-2 border-b border-divine-gold/20">
                      <div className="flex items-center space-x-3">
                        <span className="text-2xl">{item.image}</span>
                        <span className="text-rock-black font-medium">{item.name}</span>
                      </div>
                      <span className="font-bold text-divine-gold">{item.price}</span>
                    </div>
                  ))}
                </div>
                <div className="border-t border-divine-gold pt-4">
                  <div className="flex justify-between items-center text-xl font-bold">
                    <span className="text-rock-black">Total Divine Investment:</span>
                    <span className="text-divine-gold">${getTotalPrice()}</span>
                  </div>
                </div>
              </Card>
            )}

            {/* Waitlist Form */}
            <Card className="p-8 shadow-divine">
              <h3 className="text-2xl font-bold text-rock-black mb-6 text-center">
                Divine Registration Form
              </h3>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-rock-black font-bold mb-2">Sacred Name:</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    placeholder="Your divine identity"
                    className="w-full p-3 border-2 border-divine-gold/30 rounded-lg focus:border-divine-gold focus:ring-2 focus:ring-divine-gold/20"
                  />
                </div>

                <div>
                  <label className="block text-rock-black font-bold mb-2">Divine Email:</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    placeholder="your.divine@email.com"
                    className="w-full p-3 border-2 border-divine-gold/30 rounded-lg focus:border-divine-gold focus:ring-2 focus:ring-divine-gold/20"
                  />
                </div>

                <div>
                  <label className="block text-rock-black font-bold mb-2">Life Goal:</label>
                  <textarea
                    value={formData.lifeGoal}
                    onChange={(e) => handleInputChange('lifeGoal', e.target.value)}
                    placeholder="What do you seek to achieve in this divine existence?"
                    rows={3}
                    className="w-full p-3 border-2 border-divine-gold/30 rounded-lg focus:border-divine-gold focus:ring-2 focus:ring-divine-gold/20 resize-none"
                  />
                </div>

                <div>
                  <label className="block text-rock-black font-bold mb-2">Biggest Fear:</label>
                  <textarea
                    value={formData.biggestFear}
                    onChange={(e) => handleInputChange('biggestFear', e.target.value)}
                    placeholder="What shadow haunts your soul? (We're here to help you overcome it)"
                    rows={3}
                    className="w-full p-3 border-2 border-divine-gold/30 rounded-lg focus:border-divine-gold focus:ring-2 focus:ring-divine-gold/20 resize-none"
                  />
                </div>
              </div>

              <div className="mt-8 bg-divine-gold/20 p-4 rounded-lg">
                <h4 className="font-bold text-rock-black mb-2">Divine Promise:</h4>
                <ul className="text-sm text-rock-black/80 space-y-1">
                  <li>• You will be contacted 1 week before the rollout</li>
                  <li>• Personalized divine character development via Eleven Labs</li>
                  <li>• All data forwarded to: watchtower@oione.io</li>
                  <li>• Your sacred order #{orderNumber} is reserved</li>
                </ul>
              </div>

              <Button
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="w-full mt-6 bg-divine-gold text-rock-black font-bold py-4 text-lg hover:bg-divine-gold-light disabled:opacity-50"
              >
                {isSubmitting ? (
                  <div className="flex items-center justify-center space-x-2">
                    <div className="w-5 h-5 border-2 border-rock-black border-t-transparent rounded-full animate-spin" />
                    <span>Processing Divine Registration...</span>
                  </div>
                ) : (
                  'Join the Divine Waitlist'
                )}
              </Button>
            </Card>
          </div>
        ) : (
          /* Success State */
          <div className="cathedral-rise">
            <Card className="p-12 text-center shadow-divine bg-gradient-divine">
              <div className="text-8xl mb-6 animate-divine-glow">🙏</div>
              <h2 className="text-4xl font-bold text-rock-black mb-4">
                DIVINE REGISTRATION COMPLETE!
              </h2>
              <p className="text-xl text-rock-black mb-6">
                You are now blessed and chosen for the 2025 signature roll!
              </p>

              <div className="bg-gradient-rock text-white p-6 rounded-2xl mb-8">
                <h3 className="text-2xl font-bold text-divine-gold mb-4">
                  Your Sacred Order Details
                </h3>
                <div className="text-4xl font-bold text-divine-gold mb-2">
                  #{orderNumber}
                </div>
                <p className="text-lg">
                  Total Divine Investment: ${getTotalPrice()}
                </p>
                <p className="text-sm mt-4 opacity-80">
                  We trust you like we trust ourselves - payment will be collected upon rollout
                </p>
              </div>

              <div className="space-y-4 max-w-2xl mx-auto">
                <div className="bg-divine-gold/20 p-4 rounded-lg">
                  <h4 className="font-bold text-rock-black mb-2">📧 What Happens Next:</h4>
                  <ul className="text-left text-rock-black/80 space-y-2">
                    <li>• Divine notification 1 week before rollout</li>
                    <li>• Personalized character development via Eleven Labs</li>
                    <li>• Sacred merchandise shipped to your temple</li>
                    <li>• Exclusive access to divine frequencies</li>
                  </ul>
                </div>

                <Button
                  onClick={onBack}
                  className="w-full bg-divine-gold text-rock-black font-bold hover:bg-divine-gold-light"
                >
                  Return to the Cathedral
                </Button>

                <div className="mt-8 p-4 bg-rock-black/10 rounded-lg">
                  <p className="text-rock-black italic">
                    "Blessed are those who wait, for they shall receive divine merchandise." 
                    - Book of Rock, Chapter 11:11
                  </p>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default WaitlistPortal;