
import React, { useState } from 'react';
import StartScreen from './StartScreen';
import GameWorld from './GameWorld';

const GameScreen = () => {
  const [gameState, setGameState] = useState<'start' | 'playing'>('start');

  return (
    <div className="w-full h-[160px] bg-gameboy-lightest rounded">
      <div className="w-full h-full overflow-hidden animate-pixel-fade">
        {gameState === 'start' ? (
          <StartScreen onStart={() => setGameState('playing')} />
        ) : (
          <GameWorld />
        )}
      </div>
    </div>
  );
};

export default GameScreen;
