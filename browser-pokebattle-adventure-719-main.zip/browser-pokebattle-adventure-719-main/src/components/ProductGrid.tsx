import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, ShoppingCart } from 'lucide-react';
import WaitlistPortal from './WaitlistPortal';

interface Product {
  id: string;
  name: string;
  price: string;
  description: string;
  category: string;
  image: string;
  isNewDrop?: boolean;
}

interface ProductGridProps {
  onBack: () => void;
}

const ProductGrid = ({ onBack }: ProductGridProps) => {
  const [cart, setCart] = useState<Product[]>([]);
  const [showWaitlist, setShowWaitlist] = useState(false);
  const [discountCode, setDiscountCode] = useState('');

  const products: Product[] = [
    {
      id: '1',
      name: 'Divine Cross Guitar Tee',
      price: '$77.11',
      description: 'Hand-drawn by our congregation, featuring the sacred fusion of cross and guitar. Blessed by rock spirits.',
      category: 'Apparel',
      image: '✝️🎸',
      isNewDrop: true
    },
    {
      id: '2',
      name: 'Tower of Power Hoodie',
      price: '$111.11',
      description: 'Broadcast your faith in premium comfort. Features our iconic radio tower cross design.',
      category: 'Apparel',
      image: '📡✝️'
    },
    {
      id: '3',
      name: 'All Gods Aviators',
      price: '$88.11',
      description: 'See the divine truth through these blessed shades. Perfect for church services and rock concerts.',
      category: 'Accessories',
      image: '🕶️'
    },
    {
      id: '4',
      name: 'Sacred Sound Vinyl',
      price: '$55.11',
      description: 'Limited edition rock church hymnal on divine vinyl. Songs that save souls.',
      category: 'Music',
      image: '🎵'
    },
    {
      id: '5',
      name: 'Freedom Fighter Jacket',
      price: '$222.11',
      description: 'Premium leather jacket with hand-painted church artwork. Ultimate rock and roll salvation gear.',
      category: 'Apparel',
      image: '🧥'
    },
    {
      id: '6',
      name: 'Divine Device Keychain',
      price: '$33.11',
      description: 'Miniature replica of THE UNIT. Carry divine communication wherever you go.',
      category: 'Accessories',
      image: '📱',
      isNewDrop: true
    }
  ];

  const addToCart = (product: Product) => {
    setCart([...cart, product]);
  };

  const calculateDiscount = () => {
    if (discountCode.toLowerCase() === 'cherchmerch.life') {
      if (cart.length <= 11) {
        return cart.length * 11; // 11% per item
      } else {
        return 50; // 50% off everything
      }
    }
    return 0;
  };

  const getTotalPrice = () => {
    const subtotal = cart.reduce((sum, item) => {
      return sum + parseFloat(item.price.replace('$', ''));
    }, 0);
    
    const discount = calculateDiscount();
    const discountAmount = subtotal * (discount / 100);
    return (subtotal - discountAmount).toFixed(2);
  };

  if (showWaitlist) {
    return <WaitlistPortal cart={cart} onBack={() => setShowWaitlist(false)} />;
  }

  return (
    <div className="min-h-screen bg-gradient-cathedral py-8">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button
            onClick={onBack}
            variant="outline"
            className="flex items-center space-x-2"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Cathedral</span>
          </Button>

          <h1 className="text-4xl font-bold text-rock-black text-center">
            Sacred Merchandise Collection
          </h1>

          <div className="flex items-center space-x-4">
            <div className="text-right">
              <div className="text-sm text-rock-black/60">CART ITEMS</div>
              <div className="text-2xl font-bold text-divine-gold">{cart.length}</div>
            </div>
            <Button
              onClick={() => setShowWaitlist(true)}
              className="bg-divine-gold text-rock-black font-bold"
              disabled={cart.length === 0}
            >
              <ShoppingCart className="w-4 h-4 mr-2" />
              Checkout ${getTotalPrice()}
            </Button>
          </div>
        </div>

        {/* Discount Code Banner */}
        <div className="bg-gradient-rock text-white p-6 rounded-2xl mb-8 text-center">
          <h2 className="text-2xl font-bold text-divine-gold mb-2">Sacred Discount Code</h2>
          <p className="text-lg mb-4">Use code: <span className="bg-divine-gold text-rock-black px-3 py-1 rounded font-bold">cherchmerch.life</span></p>
          <p className="text-sm">11% off per item (up to 11 items), then 50% off your entire order!</p>
          
          <div className="mt-4">
            <input
              type="text"
              placeholder="Enter discount code"
              value={discountCode}
              onChange={(e) => setDiscountCode(e.target.value)}
              className="px-4 py-2 rounded-l-lg text-rock-black w-64"
            />
            <Button 
              className="bg-divine-gold text-rock-black rounded-l-none"
              onClick={() => {
                if (discountCode.toLowerCase() === 'cherchmerch.life') {
                  alert('Blessed discount activated! 🙏');
                }
              }}
            >
              Apply
            </Button>
          </div>
          
          {discountCode.toLowerCase() === 'cherchmerch.life' && (
            <div className="mt-4 p-3 bg-divine-gold text-rock-black rounded-lg">
              <p className="font-bold">🎉 DIVINE DISCOUNT ACTIVATED! 🎉</p>
              <p>Current discount: {calculateDiscount()}% off</p>
            </div>
          )}
        </div>

        {/* Product Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <Card key={product.id} className="overflow-hidden shadow-cathedral hover:shadow-divine transition-all duration-300 hover:scale-105">
              {/* Product Image */}
              <div className="h-48 bg-gradient-rock flex items-center justify-center text-6xl relative">
                {product.image}
                {product.isNewDrop && (
                  <Badge className="absolute top-2 right-2 bg-divine-gold text-rock-black">
                    NEW DROP
                  </Badge>
                )}
              </div>

              {/* Product Info */}
              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl font-bold text-rock-black">{product.name}</h3>
                  <span className="text-2xl font-bold text-divine-gold">{product.price}</span>
                </div>
                
                <Badge variant="outline" className="mb-3">
                  {product.category}
                </Badge>
                
                <p className="text-rock-black/70 mb-4 leading-relaxed">
                  {product.description}
                </p>

                <Button
                  onClick={() => addToCart(product)}
                  className="w-full bg-divine-gold text-rock-black font-bold hover:bg-divine-gold-light"
                >
                  Add to Sacred Cart
                </Button>
              </div>
            </Card>
          ))}
        </div>

        {/* Cart Summary */}
        {cart.length > 0 && (
          <div className="mt-12 bg-gradient-divine p-6 rounded-2xl shadow-cathedral">
            <h3 className="text-2xl font-bold text-rock-black mb-4">Your Sacred Cart</h3>
            <div className="space-y-2 mb-4">
              {cart.map((item, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-rock-black">{item.name}</span>
                  <span className="font-bold text-rock-black">{item.price}</span>
                </div>
              ))}
            </div>
            
            {discountCode.toLowerCase() === 'cherchmerch.life' && (
              <div className="border-t border-rock-black/20 pt-4 mb-4">
                <div className="flex justify-between items-center text-divine-gold-dark font-bold">
                  <span>Divine Discount ({calculateDiscount()}% off):</span>
                  <span>-${(cart.reduce((sum, item) => sum + parseFloat(item.price.replace('$', '')), 0) * (calculateDiscount() / 100)).toFixed(2)}</span>
                </div>
              </div>
            )}
            
            <div className="border-t border-rock-black/20 pt-4">
              <div className="flex justify-between items-center text-xl font-bold text-rock-black">
                <span>Total (All Glory):</span>
                <span>${getTotalPrice()}</span>
              </div>
            </div>
          </div>
        )}

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <p className="text-lg text-rock-black mb-4">
            Can't find what you're looking for? Visit our partner stores:
          </p>
          <div className="flex justify-center space-x-4">
            <Button
              onClick={() => window.open('https://www.deadlyprint.com', '_blank')}
              variant="outline"
              className="border-divine-gold text-divine-gold hover:bg-divine-gold hover:text-rock-black"
            >
              DeadlyPrint.com
            </Button>
            <Button
              onClick={() => window.open('https://NEVAOVA.click', '_blank')}
              variant="outline"
              className="border-divine-gold text-divine-gold hover:bg-divine-gold hover:text-rock-black"
            >
              NEVAOVA.click
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductGrid;