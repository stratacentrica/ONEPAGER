import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import RadioWidget from './RadioWidget';
import ProductGrid from './ProductGrid';
import ConfessionBooth from './ConfessionBooth';
import WaitlistPortal from './WaitlistPortal';

const ChurchHomepage = () => {
  const [currentSection, setCurrentSection] = useState('home');
  const [orderCount, setOrderCount] = useState(111);

  useEffect(() => {
    // Simulate telethon activity
    const interval = setInterval(() => {
      setOrderCount(prev => prev + Math.floor(Math.random() * 3));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-cathedral relative overflow-x-hidden">
      {/* Divine Header */}
      <header className="relative bg-gradient-rock text-white p-6 shadow-divine">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <div className="text-3xl font-bold text-divine-gold animate-divine-glow">
              ⛪ allgods.shop
            </div>
            <div className="hidden md:block text-sm italic">
              "Live life like you matter the most"
            </div>
          </div>
          
          {/* Radio Widget */}
          <div className="flex items-center space-x-4">
            <RadioWidget />
            <div className="text-right">
              <div className="text-sm">DIVINE ORDERS</div>
              <div className="text-xl font-bold text-divine-gold">{orderCount.toLocaleString()}</div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      {currentSection === 'home' && (
        <main className="relative">
          {/* Hero Section */}
          <section className="relative py-20 text-center overflow-hidden">
            {/* Background Effects */}
            <div className="absolute inset-0 bg-gradient-to-b from-divine-gold/10 via-transparent to-transparent" />
            
            <div className="container mx-auto relative z-10 cathedral-rise">
              <h1 className="text-6xl md:text-8xl font-bold text-rock-black mb-6 text-shadow-divine">
                YOU MADE IT<br />
                <span className="text-divine-gold">IN ALL YOUR GLORY!</span>
              </h1>
              
              <p className="text-2xl text-rock-black/80 mb-8 max-w-4xl mx-auto">
                Welcome to the Church of Rock and Roll and Freedom<br />
                Where all gods are good gods and salvation comes with style
              </p>

              {/* Live Telethon Banner */}
              <div className="bg-gradient-rock text-white p-6 rounded-2xl shadow-divine mb-12 max-w-4xl mx-auto">
                <div className="flex items-center justify-center space-x-4 mb-4">
                  <div className="w-4 h-4 bg-red-500 rounded-full animate-telethon-flash"></div>
                  <h2 className="text-3xl font-bold text-divine-gold">
                    🔴 LIVE 24/7 TELETHON
                  </h2>
                  <div className="w-4 h-4 bg-red-500 rounded-full animate-telethon-flash"></div>
                </div>
                <p className="text-xl mb-4">
                  "MORE POWER FOR THE TOWER!" 📡
                </p>
                <p className="text-lg italic mb-4">
                  Streaming rockchurch.fm • Divine broadcasts • Forgotten artists resurrected
                </p>
                <Button 
                  className="bg-divine-gold text-rock-black font-bold py-3 px-8 rounded-full hover:bg-divine-gold-light animate-rock-pulse"
                  onClick={() => window.open('https://s99.radiolize.com/public/wgod_radio_ggi8xn', '_blank')}
                >
                  🎵 TUNE IN TO THE DIVINE FREQUENCY 🎵
                </Button>
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-wrap justify-center gap-6 mb-12">
                <Button 
                  onClick={() => setCurrentSection('shop')}
                  className="bg-divine-gold text-rock-black font-bold py-4 px-8 rounded-full hover:bg-divine-gold-light shadow-divine text-lg"
                >
                  🛒 HOLY MERCH SHOP
                </Button>
                <Button 
                  onClick={() => setCurrentSection('confessions')}
                  className="bg-rock-black text-divine-gold font-bold py-4 px-8 rounded-full hover:bg-rock-black-light shadow-cathedral text-lg"
                >
                  ✝️ CONFESS FOR 33% OFF
                </Button>
                <Button 
                  onClick={() => window.open('https://www.deadlyprint.com', '_blank')}
                  className="bg-accent text-white font-bold py-4 px-8 rounded-full hover:bg-accent/90 shadow-glow text-lg"
                >
                  🎭 INSTANT MERCH (External)
                </Button>
              </div>
            </div>
          </section>

          {/* Mission Statement */}
          <section className="py-16 bg-gradient-divine text-rock-black">
            <div className="container mx-auto text-center px-6">
              <h2 className="text-4xl font-bold mb-6">Our Divine Mission</h2>
              <p className="text-xl max-w-4xl mx-auto leading-relaxed">
                At the Church of Rock and Roll and Freedom, we believe in living life like you matter the most. 
                Our sacred mission is to spread the word that all gods are good gods through the divine power of 
                rock and roll, freedom, and fabulous merchandise that makes you look absolutely divine.
              </p>
              <div className="mt-8 text-lg italic">
                📍 Paradiso, California 696969 • ☎️ 778-725-3888
              </div>
            </div>
          </section>

          {/* Featured Products Preview */}
          <section className="py-16">
            <div className="container mx-auto px-6">
              <h2 className="text-4xl font-bold text-center text-rock-black mb-12">
                Sacred Merchandise Collection
              </h2>
              <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
                {[
                  {
                    title: "Divine Cross Guitar Tee",
                    price: "$77.11",
                    description: "Hand-drawn by our congregation, blessed by rock spirits"
                  },
                  {
                    title: "Tower of Power Hoodie", 
                    price: "$111.11",
                    description: "Broadcast your faith in premium comfort"
                  },
                  {
                    title: "All Gods Accessories",
                    price: "$33.11",
                    description: "Sacred symbols for the modern worshipper"
                  }
                ].map((product, index) => (
                  <Card key={index} className="p-6 text-center shadow-cathedral hover:shadow-divine transition-all duration-300 hover:scale-105">
                    <div className="w-32 h-32 bg-gradient-rock rounded-lg mx-auto mb-4 flex items-center justify-center">
                      <span className="text-divine-gold text-4xl">✝️🎸</span>
                    </div>
                    <h3 className="text-xl font-bold text-rock-black mb-2">{product.title}</h3>
                    <p className="text-divine-gold font-bold text-2xl mb-2">{product.price}</p>
                    <p className="text-rock-black/70">{product.description}</p>
                  </Card>
                ))}
              </div>
              <div className="text-center mt-8">
                <Button 
                  onClick={() => setCurrentSection('shop')}
                  className="bg-divine-gold text-rock-black font-bold py-3 px-8 rounded-full hover:bg-divine-gold-light"
                >
                  View All Sacred Items
                </Button>
              </div>
            </div>
          </section>
        </main>
      )}

      {currentSection === 'shop' && (
        <ProductGrid onBack={() => setCurrentSection('home')} />
      )}

      {currentSection === 'confessions' && (
        <ConfessionBooth onBack={() => setCurrentSection('home')} />
      )}

      {currentSection === 'waitlist' && (
        <WaitlistPortal onBack={() => setCurrentSection('home')} />
      )}

      {/* Footer */}
      <footer className="bg-gradient-rock text-white py-12">
        <div className="container mx-auto px-6 text-center">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-divine-gold font-bold mb-4">Divine Links</h3>
              <div className="space-y-2">
                <a href="https://thefakelabel.com" className="block hover:text-divine-gold transition-colors">thefakelabel.com</a>
                <a href="https://fistpumpmedia.com" className="block hover:text-divine-gold transition-colors">fistpumpmedia.com</a>
                <a href="https://rockchurch.fm" className="block hover:text-divine-gold transition-colors">rockchurch.fm</a>
              </div>
            </div>
            <div>
              <h3 className="text-divine-gold font-bold mb-4">Sacred Shopping</h3>
              <div className="space-y-2">
                <a href="https://www.deadlyprint.com" className="block hover:text-divine-gold transition-colors">DeadlyPrint.com</a>
                <a href="https://www.etsy.com/ca/shop/DeadlyPrint" className="block hover:text-divine-gold transition-colors">Etsy Shop</a>
                <a href="https://NEVAOVA.click" className="block hover:text-divine-gold transition-colors">NEVAOVA.click</a>
              </div>
            </div>
            <div>
              <h3 className="text-divine-gold font-bold mb-4">Contact the Divine</h3>
              <p>Paradiso, California 696969</p>
              <p>778-725-3888</p>
              <p>watchtower@oione.io</p>
            </div>
            <div>
              <h3 className="text-divine-gold font-bold mb-4">Sacred Codes</h3>
              <p className="bg-divine-gold text-rock-black px-3 py-1 rounded font-bold">
                cherchmerch.life
              </p>
              <p className="text-sm mt-2">11% off up to 11 items, then 50% off everything!</p>
            </div>
          </div>
          <div className="border-t border-white/20 pt-8">
            <p className="text-lg">
              © 2025 Church of Rock and Roll and Freedom • All Gods Are Good Gods™
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default ChurchHomepage;