
import React, { useState, useEffect } from 'react';

const GameWorld = () => {
  const [position, setPosition] = useState({ x: 50, y: 50 });

  const movePlayer = (direction: 'up' | 'down' | 'left' | 'right') => {
    const step = 10;
    setPosition(prev => {
      switch (direction) {
        case 'up':
          return { ...prev, y: Math.max(0, prev.y - step) };
        case 'down':
          return { ...prev, y: Math.min(140, prev.y + step) };
        case 'left':
          return { ...prev, x: Math.max(0, prev.x - step) };
        case 'right':
          return { ...prev, x: Math.min(140, prev.x + step) };
      }
    });
  };

  // Handle keyboard events
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowUp':
          movePlayer('up');
          break;
        case 'ArrowDown':
          movePlayer('down');
          break;
        case 'ArrowLeft':
          movePlayer('left');
          break;
        case 'ArrowRight':
          movePlayer('right');
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="relative w-full h-full bg-gameboy-light">
      {/* Player character */}
      <div
        className="absolute w-5 h-5 bg-gameboy-darkest transition-all duration-200"
        style={{ left: `${position.x}px`, top: `${position.y}px` }}
      />
      
      {/* Simple instructions */}
      <div className="absolute bottom-2 right-2 text-[8px] text-gameboy-darkest">
        Use D-pad to move
      </div>
    </div>
  );
};

export default GameWorld;
