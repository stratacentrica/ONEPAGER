import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Volume2, VolumeX, Radio } from 'lucide-react';

const RadioWidget = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.7);
  const [isMuted, setIsMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const radioUrl = "https://s99.radiolize.com/public/wgod_radio_ggi8xn";

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);

  const togglePlay = () => {
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().catch(console.error);
      setIsPlaying(true);
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  return (
    <div className="flex items-center space-x-3 bg-divine-gold/20 backdrop-blur-sm rounded-lg p-3 border border-divine-gold/30">
      <audio 
        ref={audioRef}
        src={radioUrl}
        preload="none"
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onError={() => setIsPlaying(false)}
      />
      
      {/* Live Indicator */}
      <div className="flex items-center space-x-2">
        <div className={`w-2 h-2 rounded-full ${isPlaying ? 'bg-red-500 animate-pulse' : 'bg-gray-400'}`} />
        <Radio className="w-4 h-4 text-divine-gold" />
      </div>

      {/* Play/Pause Button */}
      <Button
        onClick={togglePlay}
        variant="ghost"
        size="sm"
        className="text-divine-gold hover:bg-divine-gold hover:text-rock-black transition-all duration-300"
      >
        {isPlaying ? '⏸️' : '▶️'}
      </Button>

      {/* Volume Control */}
      <div className="flex items-center space-x-2">
        <Button
          onClick={toggleMute}
          variant="ghost"
          size="sm"
          className="text-divine-gold hover:bg-divine-gold hover:text-rock-black p-1"
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </Button>
        
        <input
          type="range"
          min="0"
          max="1"
          step="0.1"
          value={isMuted ? 0 : volume}
          onChange={(e) => setVolume(parseFloat(e.target.value))}
          className="w-16 h-1 bg-divine-gold/30 rounded-lg appearance-none cursor-pointer slider"
        />
      </div>

      {/* Station Info */}
      <div className="text-xs text-divine-gold font-semibold hidden sm:block">
        ROCK CHURCH FM
      </div>

    </div>
  );
};

export default RadioWidget;