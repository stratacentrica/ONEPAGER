
import React from 'react';
import GameScreen from './GameScreen';

const GameBoy = () => {
  return (
    <div className="relative w-[320px] h-[480px] bg-gray-200 rounded-[20px] p-8 shadow-xl animate-screen-on">
      {/* Game Boy body design */}
      <div className="absolute top-2 left-4 flex gap-2">
        <div className="w-2 h-2 rounded-full bg-red-500 opacity-50"></div>
        <div className="w-16 h-1 bg-gray-400 rounded"></div>
      </div>
      
      {/* Screen area */}
      <div className="bg-gray-800 p-4 rounded-lg">
        <div className="flex items-center justify-between mb-2">
          <div className="text-xs text-gray-500">DOT MATRIX WITH STEREO SOUND</div>
          <div className="w-2 h-2 rounded-full bg-red-500"></div>
        </div>
        <GameScreen />
      </div>
      
      {/* Controls */}
      <div className="mt-8">
        <div className="flex justify-between items-center">
          {/* D-Pad */}
          <div className="relative w-24 h-24">
            <button 
              className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-8 bg-gray-800 hover:bg-gray-700 active:bg-gray-600"
              onMouseDown={() => window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowUp' }))}
            ></button>
            <button 
              className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-8 bg-gray-800 hover:bg-gray-700 active:bg-gray-600"
              onMouseDown={() => window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown' }))}
            ></button>
            <button 
              className="absolute left-0 top-1/2 -translate-y-1/2 w-8 h-8 bg-gray-800 hover:bg-gray-700 active:bg-gray-600"
              onMouseDown={() => window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft' }))}
            ></button>
            <button 
              className="absolute right-0 top-1/2 -translate-y-1/2 w-8 h-8 bg-gray-800 hover:bg-gray-700 active:bg-gray-600"
              onMouseDown={() => window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight' }))}
            ></button>
          </div>
          
          {/* A B buttons */}
          <div className="flex gap-4">
            <button className="w-12 h-12 rounded-full bg-gray-800 hover:bg-gray-700 active:bg-gray-600 transform rotate-12">B</button>
            <button className="w-12 h-12 rounded-full bg-gray-800 hover:bg-gray-700 active:bg-gray-600 transform rotate-12">A</button>
          </div>
        </div>
        
        {/* Start/Select */}
        <div className="flex justify-center gap-8 mt-8">
          <button className="w-12 h-4 bg-gray-800 hover:bg-gray-700 active:bg-gray-600 rounded-full transform -rotate-12">SELECT</button>
          <button className="w-12 h-4 bg-gray-800 hover:bg-gray-700 active:bg-gray-600 rounded-full transform -rotate-12">START</button>
        </div>
      </div>
    </div>
  );
};

export default GameBoy;
