import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';

interface ConfessionBoothProps {
  onBack: () => void;
}

const ConfessionBooth = ({ onBack }: ConfessionBoothProps) => {
  const [confession, setConfession] = useState('');
  const [isConfessing, setIsConfessing] = useState(false);
  const [hasConfessed, setHasConfessed] = useState(false);
  const [discountCode, setDiscountCode] = useState('');

  const handleConfession = async () => {
    if (confession.trim().length < 10) {
      toast.error('Your confession must be at least 10 characters for divine forgiveness!');
      return;
    }

    setIsConfessing(true);
    
    // Simulate divine processing
    setTimeout(() => {
      setIsConfessing(false);
      setHasConfessed(true);
      
      // Generate unique discount code
      const code = `BLESSED${Math.floor(Math.random() * 1000)}`;
      setDiscountCode(code);
      
      toast.success('Your confession has been received! 33% discount granted!');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-cathedral py-8">
      <div className="container mx-auto px-6 max-w-4xl">
        {/* Header */}
        <div className="flex items-center mb-8">
          <Button
            onClick={onBack}
            variant="outline"
            className="flex items-center space-x-2"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Cathedral</span>
          </Button>
          <h1 className="text-4xl font-bold text-rock-black text-center flex-1">
            Sacred Confession Booth
          </h1>
        </div>

        {/* Confession Interface */}
        <div className="cathedral-rise">
          <Card className="p-8 shadow-divine bg-gradient-cathedral border-2 border-divine-gold/30">
            {!hasConfessed ? (
              <>
                {/* Confession Form */}
                <div className="text-center mb-8">
                  <div className="text-6xl mb-4">✝️</div>
                  <h2 className="text-3xl font-bold text-rock-black mb-4">
                    Confess Your Sins, Receive Divine Discount
                  </h2>
                  <p className="text-lg text-rock-black/70 mb-6">
                    Unburden your soul and receive 33% off your first purchase. 
                    All confessions are sacred and confidential between you and the divine.
                  </p>
                </div>

                <div className="space-y-6">
                  <div>
                    <label className="block text-rock-black font-bold mb-2">
                      Share your confession with the divine:
                    </label>
                    <textarea
                      value={confession}
                      onChange={(e) => setConfession(e.target.value)}
                      placeholder="Speak your truth here... The divine is listening with love and forgiveness."
                      className="w-full h-40 p-4 border-2 border-divine-gold/30 rounded-lg focus:border-divine-gold focus:ring-2 focus:ring-divine-gold/20 resize-none"
                      disabled={isConfessing}
                    />
                    <div className="text-right text-sm text-rock-black/50 mt-1">
                      {confession.length} characters (minimum 10 required)
                    </div>
                  </div>

                  <div className="bg-divine-gold/20 p-4 rounded-lg">
                    <h3 className="font-bold text-rock-black mb-2">🙏 Divine Promise:</h3>
                    <ul className="text-sm text-rock-black/80 space-y-1">
                      <li>• Your confession is completely confidential</li>
                      <li>• All gods are good gods - no judgment here</li>
                      <li>• Receive immediate 33% discount code</li>
                      <li>• Your soul gets lighter, your cart gets cheaper</li>
                    </ul>
                  </div>

                  <Button
                    onClick={handleConfession}
                    disabled={confession.trim().length < 10 || isConfessing}
                    className="w-full bg-divine-gold text-rock-black font-bold py-4 text-lg hover:bg-divine-gold-light disabled:opacity-50"
                  >
                    {isConfessing ? (
                      <div className="flex items-center justify-center space-x-2">
                        <div className="w-5 h-5 border-2 border-rock-black border-t-transparent rounded-full animate-spin" />
                        <span>Processing Divine Forgiveness...</span>
                      </div>
                    ) : (
                      'Submit Sacred Confession'
                    )}
                  </Button>
                </div>
              </>
            ) : (
              <>
                {/* Confession Success */}
                <div className="text-center">
                  <div className="text-8xl mb-6 animate-divine-glow">🙏</div>
                  <h2 className="text-4xl font-bold text-divine-gold mb-4">
                    Divine Forgiveness Granted!
                  </h2>
                  <p className="text-xl text-rock-black mb-8">
                    Your confession has been received with love. Your soul is lighter and your discount is ready!
                  </p>

                  <div className="bg-gradient-rock text-white p-6 rounded-2xl mb-8">
                    <h3 className="text-2xl font-bold text-divine-gold mb-4">
                      Your Sacred Discount Code
                    </h3>
                    <div className="bg-divine-gold text-rock-black px-6 py-3 rounded-lg text-3xl font-bold mb-4">
                      {discountCode}
                    </div>
                    <p className="text-lg">
                      33% OFF your first purchase
                    </p>
                    <p className="text-sm mt-2 opacity-80">
                      Use this code at checkout to receive divine savings
                    </p>
                  </div>

                  <div className="space-y-4">
                    <Button
                      onClick={() => {
                        navigator.clipboard.writeText(discountCode);
                        toast.success('Discount code copied to clipboard!');
                      }}
                      variant="outline"
                      className="w-full border-divine-gold text-divine-gold hover:bg-divine-gold hover:text-rock-black"
                    >
                      📋 Copy Discount Code
                    </Button>
                    
                    <Button
                      onClick={onBack}
                      className="w-full bg-divine-gold text-rock-black font-bold hover:bg-divine-gold-light"
                    >
                      Return to Sacred Shopping
                    </Button>
                  </div>

                  <div className="mt-8 p-4 bg-divine-gold/20 rounded-lg">
                    <p className="text-rock-black italic">
                      "Blessed are those who confess, for they shall receive divine discounts." 
                      - Book of Rock, Chapter 7:11
                    </p>
                  </div>
                </div>
              </>
            )}
          </Card>
        </div>

        {/* Additional Info */}
        <div className="mt-12 text-center">
          <h3 className="text-2xl font-bold text-rock-black mb-4">
            About Sacred Confessions
          </h3>
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="p-4 shadow-cathedral">
              <div className="text-3xl mb-2">🔒</div>
              <h4 className="font-bold text-rock-black mb-2">Confidential</h4>
              <p className="text-sm text-rock-black/70">
                Your confessions are sacred and private between you and the divine.
              </p>
            </Card>
            <Card className="p-4 shadow-cathedral">
              <div className="text-3xl mb-2">💝</div>
              <h4 className="font-bold text-rock-black mb-2">No Judgment</h4>
              <p className="text-sm text-rock-black/70">
                All gods are good gods. We embrace all souls with love and acceptance.
              </p>
            </Card>
            <Card className="p-4 shadow-cathedral">
              <div className="text-3xl mb-2">🎁</div>
              <h4 className="font-bold text-rock-black mb-2">Divine Rewards</h4>
              <p className="text-sm text-rock-black/70">
                Honest confession leads to spiritual lightness and material savings.
              </p>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConfessionBooth;