import React, { useState, useEffect } from 'react';
import { useIsMobile } from '@/hooks/use-mobile';

interface DivineUnitProps {
  onActivation: () => void;
}

const DivineUnit = ({ onActivation }: DivineUnitProps) => {
  const [isActivated, setIsActivated] = useState(false);
  const [glowIntensity, setGlowIntensity] = useState(0);
  const isMobile = useIsMobile();

  const handleInteraction = () => {
    if (!isActivated) {
      setIsActivated(true);
      // Trigger dramatic activation sequence
      setTimeout(() => {
        onActivation();
      }, 1500);
    }
  };

  useEffect(() => {
    // Pulsing glow effect
    const interval = setInterval(() => {
      setGlowIntensity(prev => (prev + 1) % 100);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  const interactionText = isMobile 
    ? "PLACE YOUR THUMB ON THE DIVINE DEVICE" 
    : "PUT YOUR HAND ON THE SCREEN SO YOU CAN BE SEEN";

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-cathedral relative overflow-hidden">
      {/* Divine Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-divine-gold/10 via-transparent to-rock-black/10" />
      
      {/* Radiating Lines */}
      <div className="absolute inset-0 opacity-20">
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute w-px h-full bg-divine-gold origin-bottom"
            style={{
              left: '50%',
              transform: `rotate(${i * 30}deg)`,
              transformOrigin: 'bottom center',
            }}
          />
        ))}
      </div>

      {/* Main Content */}
      <div className="relative z-10 text-center cathedral-rise">
        {/* Title */}
        <div className="mb-8">
          <h1 className="text-6xl md:text-8xl font-bold text-rock-black text-shadow-divine mb-4">
            THE UNIT
          </h1>
          <p className="text-xl md:text-2xl text-rock-black/80 italic">
            Divine Device • Future Oracle • Spirit Communicator
          </p>
        </div>

        {/* The Divine Device */}
        <div className="relative mb-8">
          <div 
            className={`relative w-80 h-96 mx-auto cursor-pointer transition-all duration-500 ${
              isActivated ? 'animate-handprint-activate scale-110' : 'hover:scale-105'
            }`}
            onClick={handleInteraction}
            style={{
              filter: `drop-shadow(0 0 ${20 + glowIntensity/2}px hsl(45 100% 50% / ${0.3 + glowIntensity/200}))`
            }}
          >
            {/* Phone Base */}
            <div className="absolute inset-0 bg-phone-cream rounded-2xl border-4 border-phone-brown shadow-cathedral">
              {/* Screen */}
              <div className="absolute top-8 left-8 right-8 h-32 bg-phone-orange rounded-lg border-2 border-phone-brown overflow-hidden">
                <div className="w-full h-full bg-gradient-to-b from-phone-orange to-orange-600 flex items-center justify-center">
                  <div className="text-2xl font-bold text-white digital-font">
                    {isActivated ? "CONNECTING..." : "13:18"}
                  </div>
                </div>
              </div>

              {/* Speaker Grille */}
              <div className="absolute top-44 left-12 right-12 h-16 bg-phone-brown rounded-lg">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="w-full h-1 bg-phone-chrome/50 my-1 rounded" />
                ))}
              </div>

              {/* Rotary Dial */}
              <div className="absolute bottom-16 left-1/2 transform -translate-x-1/2 w-32 h-32 bg-phone-chrome rounded-full border-4 border-phone-brown relative">
                <div className="absolute inset-4 bg-phone-brown rounded-full">
                  {[...Array(10)].map((_, i) => {
                    const angle = (i * 36) - 90;
                    return (
                      <div
                        key={i}
                        className="absolute w-3 h-6 bg-phone-chrome rounded-sm"
                        style={{
                          left: '50%',
                          top: '50%',
                          transform: `translate(-50%, -50%) rotate(${angle}deg) translateY(-20px)`,
                        }}
                      />
                    );
                  })}
                </div>
              </div>

              {/* Divine Cross Symbol */}
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-divine-gold">
                <svg width="40" height="40" viewBox="0 0 40 40" className="animate-divine-glow">
                  <path d="M20 0 L20 40 M0 20 L40 20" stroke="currentColor" strokeWidth="3" fill="none" />
                  <circle cx="20" cy="20" r="15" stroke="currentColor" strokeWidth="2" fill="none" opacity="0.5" />
                </svg>
              </div>

              {/* Handprint/Thumbprint Indicator */}
              <div className={`absolute inset-0 flex items-center justify-center transition-opacity duration-500 ${
                isActivated ? 'opacity-0' : 'opacity-100'
              }`}>
                <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 w-16 h-20 border-2 border-divine-gold border-dashed rounded-lg animate-rock-pulse" />
              </div>
            </div>
          </div>
        </div>

        {/* Interaction Instructions */}
        <div className="mb-8">
          <p className="text-2xl font-bold text-divine-gold mb-2 animate-rock-pulse">
            {interactionText}
          </p>
          <p className="text-lg text-rock-black/70">
            Experience the divine connection • Channel the future • Speak with spirits
          </p>
        </div>

        {/* Church Branding */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-rock-black mb-2">
            CHURCH OF ROCK AND ROLL AND FREEDOM
          </h2>
          <p className="text-divine-gold font-semibold text-lg">
            "All Gods Are Good Gods"
          </p>
        </div>
      </div>

      {/* Loading Overlay */}
      {isActivated && (
        <div className="absolute inset-0 bg-divine-gold/20 backdrop-blur-sm flex items-center justify-center z-20">
          <div className="text-center">
            <div className="w-32 h-32 border-8 border-divine-gold border-t-transparent rounded-full animate-spin mb-4" />
            <p className="text-2xl font-bold text-rock-black">
              DIVINE CONNECTION ESTABLISHED
            </p>
            <p className="text-lg text-rock-black/80">
              Preparing your salvation experience...
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default DivineUnit;