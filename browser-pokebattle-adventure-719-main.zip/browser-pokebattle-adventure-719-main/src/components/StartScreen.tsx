
import React from 'react';

interface StartScreenProps {
  onStart: () => void;
}

const StartScreen = ({ onStart }: StartScreenProps) => {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center bg-gameboy-lightest p-4">
      <h1 className="text-gameboy-darkest text-xl mb-4 font-bold">POKEMON</h1>
      <p className="text-gameboy-dark text-sm mb-4">Press START</p>
      <button
        onClick={onStart}
        className="text-gameboy-darkest hover:text-gameboy-dark transition-colors"
      >
        START GAME
      </button>
    </div>
  );
};

export default StartScreen;
